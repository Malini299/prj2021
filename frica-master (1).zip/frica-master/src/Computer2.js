import React from 'react'

function Computer2() {
    return (
        <div className="com2">
            
            <div class="computers_section layout_padding">
         <div class="container">
            <h1 class="computers_taital">Computers & Laptop</h1>
         </div>

      </div>

        </div>
    )
}

export default Computer2
