import React from 'react';
import './Category.css';

function Category() {
    return (
        <div className="categry">

<nav className="navbar navbar-light bg-dark" id="navb">
  <div className="container-fluid">

      <a href="#" className="und">
  <span className="cat">CATEGORIES</span>&emsp;
  <span className="catgs">Man'sFashion</span>&emsp;
  <span className="catgs">Woman'sFashion</span>&emsp;
  <span className="catgs">Beauty</span>&emsp;
  <span className="catgs">Mobiles</span>&emsp;
  <span className="catgs">Computers</span>&emsp;
  <span className="catgs">Watches</span>&emsp;
  <span className="catgs">Kitchen</span>&emsp;
  <span className="catgs">Sports</span>
  </a>
  
  </div>
</nav> 
        
        </div>
    )
}

export default Category
